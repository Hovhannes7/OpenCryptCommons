---
name: Bug report
about: Report a bug or repository issue
title: "[Bug] "
labels: bug
assignees: ''
---

## Summary

Describe the bug clearly.

## Steps to reproduce

1.
2.
3.

## Expected behavior

Describe what you expected to happen.

## Actual behavior

Describe what happened instead.

## Additional context

Add any context, screenshots, or links here.
