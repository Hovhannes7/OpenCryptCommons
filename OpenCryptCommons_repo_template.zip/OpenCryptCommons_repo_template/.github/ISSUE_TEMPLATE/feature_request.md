---
name: Feature request
about: Suggest an idea or project improvement
title: "[Feature] "
labels: enhancement
assignees: ''
---

## Summary

Describe the requested feature or improvement.

## Why it matters

Explain why this would be useful for the project.

## Possible approach

If you have a concrete suggestion, describe it here.

## Additional context

Add any relevant standards, references, or examples.
